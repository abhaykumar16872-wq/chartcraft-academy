/**
 * ChartCraft Academy - GA4 Event Tracking
 * Measurement ID is configured in each HTML page's <head>.
 *
 * Events are intentionally generic and non-sensitive:
 * - cca_cta_click
 * - cca_course_view
 * - cca_lesson_start
 * - cca_progress_action
 * - cca_search
 * - cca_navigation_click
 */

(function () {
  'use strict';

  function track(name, params) {
    if (typeof window.gtag !== 'function') return;
    window.gtag('event', name, params || {});
  }

  function cleanText(value, maxLength) {
    return String(value || '').replace(/\s+/g, ' ').trim().slice(0, maxLength || 100);
  }

  document.addEventListener('click', function (event) {
    const target = event.target.closest('a, button');
    if (!target) return;

    const text = cleanText(
      target.getAttribute('aria-label') ||
      target.getAttribute('title') ||
      target.textContent,
      80
    );

    const href = target.getAttribute('href') || '';

    // Navigation events
    if (target.matches('a.nav-link, a.brand-logo')) {
      track('cca_navigation_click', {
        link_text: text,
        destination: href
      });
      return;
    }

    // Course/lesson links and cards
    if (
      target.matches('[data-course-id], [data-course], .course-card, .course-card a, a[href*="course-details"], a[href*="lessons"]')
    ) {
      track('cca_course_view', {
        link_text: text,
        destination: href
      });
      return;
    }

    // Important CTA/button interactions
    if (
      target.matches(
        '.btn, button[type="submit"], .cta, [data-action], .start-course, .start-lesson, .complete-lesson'
      )
    ) {
      track('cca_cta_click', {
        button_text: text
      });
    }
  });

  // Track search submissions without recording search text.
  document.addEventListener('submit', function (event) {
    const form = event.target;
    if (!form.matches('form')) return;

    if (
      form.matches('.search-form, [role="search"] form') ||
      form.querySelector('input[type="search"], input[name*="search" i]')
    ) {
      track('cca_search', {
        search_context: 'site_search'
      });
    }
  });

  // Track clicks on glossary terms without sending the term itself.
  document.addEventListener('click', function (event) {
    const term = event.target.closest('[data-glossary-term], .glossary-term');
    if (!term) return;

    track('cca_glossary_view', {
      glossary_context: 'glossary'
    });
  });
})();
