# ChartCraft Academy - GA4 Setup

Measurement ID:
`G-4Y4MCDEMW6`

## What was changed
- Added the GA4 Google tag to every HTML page.
- Enabled normal `page_view` collection.
- Added optional DebugView mode using `?ga_debug=1`.
- Added non-sensitive interaction events through `js/analytics.js`.
- Avoided hard-coding any GitHub credentials or tokens.

## Test
1. Deploy the site.
2. Open the deployed site with `?ga_debug=1`.
3. In Google Analytics, open Admin -> Data display -> DebugView.
4. Visit several pages and interact with the site.
5. Confirm `page_view` and interaction events appear.
6. Remove `?ga_debug=1` for normal use.

Standard Reports/Reports Snapshot can take longer to populate than Realtime/DebugView.
